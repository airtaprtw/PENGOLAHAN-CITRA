import cv2
import numpy as np
import matplotlib.pyplot as plt

# Baca dua citra
img1 = cv2.imread('aurora.jpg')
img2 = cv2.imread('amogus.jpg')

# Pastikan kedua citra memiliki ukuran yang sama
img2 = cv2.resize(img2, (img1.shape[1], img1.shape[0]))

# Operasi penambahan citra
added_image = cv2.addWeighted(img1, 0.5, img2, 0.5, 0)

# Operasi pengurangan citra
subtracted_image = cv2.subtract(img1, img2)

# Tampilkan hasil
plt.figure(figsize=(12, 6))
plt.subplot(1, 3, 1)
plt.imshow(cv2.cvtColor(img1, cv2.COLOR_BGR2RGB))
plt.title('aurora.jpg')
plt.subplot(1, 3, 2)
plt.imshow(cv2.cvtColor(img2, cv2.COLOR_BGR2RGB))
plt.title('amogus.jpg')
plt.subplot(1, 3, 3)
plt.imshow(cv2.cvtColor(added_image, cv2.COLOR_BGR2RGB))
plt.title('Hasil Penambahan Citra')
plt.show()

plt.figure(figsize=(12, 6))
plt.subplot(1, 3, 1)
plt.imshow(cv2.cvtColor(img1, cv2.COLOR_BGR2RGB))
plt.title('aurora.jpg')
plt.subplot(1, 3, 2)
plt.imshow(cv2.cvtColor(img2, cv2.COLOR_BGR2RGB))
plt.title('amogus.jpg')
plt.subplot(1, 3, 3)
plt.imshow(cv2.cvtColor(subtracted_image, cv2.COLOR_BGR2RGB))
plt.title('Hasil Pengurangan Citra')
plt.show()
